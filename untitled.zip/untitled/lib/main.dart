import 'package:flutter/material.dart';

void main() {
  runApp(const Center(
    child: Text(
        'Flutter - bu bitta kod bazasi asosida mobile, web va desktop uchun chiroyli, native'
        "          kompilyatsiya qilingan ilovalarni yaratish uchun Google-ning moslashuvchan"
        "          mo’jaz, qulay UI toolkiti hisoblanadi",
        textDirection: TextDirection.ltr),
  ));
}
